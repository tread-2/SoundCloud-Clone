import './App.css';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from './components/Navbar';
import Home from './components/Home';

const Explore = () => <h2 className="text-white text-center mt-10">Explore Pages</h2>
const Profile = () => <h2 className="text-white text-center mt-10">Profile Pages</h2>
const Feed = () => <h2 className="text-white text-center mt-10">Feed Pages</h2>
const Library = () => <h2 className="text-white text-center mt-10">Library Pages</h2>
const Upload = () => <h2 className="text-white text-center mt-10">Upload Pages</h2>
const Settings = () => <h2 className="text-white text-center mt-10">Settings Pages</h2>

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/explore" element={<Explore />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/feed" element={<Feed />} />
        <Route path="/library" element={<Library />} />
        <Route path="/upload" element={<Upload />} />
        <Route path="/settings" element={<Settings />} />
      </Routes>
    </Router>
  );
}

export default App;
