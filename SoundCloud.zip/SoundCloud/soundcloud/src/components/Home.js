import { useState } from "react";
import "./styles/Home.css"; 

const mockTracks = [
    {
        id: 1,
        title: "Lo-Fi Chill Beats",
        artist: "DJ Chill",
        artwork: "https://source.unsplash.com/200x200/?music,headphones",
    },
    {
        id: 2,
        title: "Deep House Vibes",
        artist: "HouseMaster",
        artwork: "https://source.unsplash.com/200x200/?dj,party",
    },
    {
        id: 3,
        title: "Synthwave Dreams",
        artist: "RetroWave",
        artwork: "https://source.unsplash.com/200x200/?neon,city",
    },
];

const Home = () => {
    const [tracks] = useState(mockTracks);

    return (
        <div className="home-container">
            <h1 className="page-title">Trending Tracks</h1>
            <div className="tracks-container">
                {tracks.map((track) => (
                    <div key={track.id} className="track-card">
                        <img src={track.artwork} alt={track.title} />
                        <h2 className="track-title">{track.title}</h2>
                        <p className="track-artist">{track.artist}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Home;
