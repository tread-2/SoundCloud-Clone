import { Link } from 'react-router-dom';

const Navbar = () => {
    return (
        <nav className="bg-gray-900 text-white p-4 flex justify-between items-center">
            <h1 className="text-x1 font-bold">SoundCloud Clone</h1>
            <div>
                <Link to="/" className="mx-2">Home</Link>
                <Link to="/explore" className="mx-2">Explore</Link>
                <Link to="/profile" className="mx-2">Profile</Link>
                <Link to="/feed" className="mx-2">Feed</Link>
                <Link to="/library" className="mx-2">Library</Link>
                <Link to="/upload" className="mx-2">Upload</Link>
                <Link to="/settings" className="mx-2">Settings</Link>
            </div>
        </nav>
    );
};

export default Navbar;